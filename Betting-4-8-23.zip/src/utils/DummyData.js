const transactionHistoryDummy = [
    {
        _id: "64c20d9d1fd037191b1fdbf5",
        userId: "64bf611017e3af73652b20c6",
        userName: "Rohit sharma",
        email: "rohitsharma@gmail.com",
        hashKey: "0Kdsfdjhjsff55sdfsdfsdfjuuuiiwkmLnndnsadmnadmnmdnsmnasd",
        network: 0,
        amount: 0,
        is_deleted: 0,
        createdAt: "2023-07-27T06:24:29.755Z",
        updatedAt: "2023-07-27T06:24:29.755Z",
        __v: 0
    },
    {
        _id: "64c20d9d1fd037191b1fdbf6",
        userId: "64bf611017e3af73652b20c6",
        userName: "Chetan patidar",
        email: "rohitsharma@gmail.com",
        hashKey: "0Kdsfdjhjsff55sdfsdfsdfjuuuiiwkmLnndnsadmnadmnmdnsmnasd",
        network: 0,
        amount: 0,
        is_deleted: 0,
        createdAt: "2023-07-27T06:24:29.755Z",
        updatedAt: "2023-07-27T06:24:29.755Z",
        __v: 0
    },
    {
        _id: "64c20d9d1fd037191b1fdbf6",
        userId: "64bf8b65dea15b6e73b4f731",
        userName: "Rohit sharma",
        email: "rohitsharma@gmail.com",
        hashKey: "0Kdsfdjhjsff55sdfsdfsdfjuuuiiwkmLnndnsadmnadmnmdnsmnasd",
        network: 0,
        amount: 0,
        is_deleted: 0,
        createdAt: "2023-07-27T06:24:29.755Z",
        updatedAt: "2023-07-27T06:24:29.755Z",
        __v: 0
    },
    {
        _id: "64c20d9d1fd037191b1fdbf7",
        userId: "64bf92530aff0dea5d8d1388",
        userName: "Rohit sharma",
        email: "rohitsharma@gmail.com",
        hashKey: "0Kdsfdjhjsff55sdfsdfsdfjuuuiiwkmLnndnsadmnadmnmdnsmnasd",
        network: 0,
        amount: 0,
        is_deleted: 0,
        createdAt: "2023-07-27T06:24:29.755Z",
        updatedAt: "2023-07-27T06:24:29.755Z",
        __v: 0
    },
    {
        _id: "64c20d9d1fd037191b1fdbf8",
        userId: "64bf92530aff0dea5d8d1388",
        userName: "Rohit sharma",
        email: "rohitsharma@gmail.com",
        hashKey: "0Kdsfdjhjsff55sdfsdfsdfjuuuiiwkmLnndnsadmnadmnmdnsmnasd",
        network: 0,
        amount: 0,
        is_deleted: 0,
        createdAt: "2023-07-27T06:24:29.755Z",
        updatedAt: "2023-07-27T06:24:29.755Z",
        __v: 0
    }
]

const referralWorkDummy = [
    "Get your unique referral link or code.",
    "Share it with your friends easily from the app.",
    "When your friends sign up using your link or code, they get rewarded, and you get rewarded too!",
    "The more friends you invite, the more rewards you can earn.",
    "Your friends may also receive a welcome bonus for joining through your link.",
    "Make sure your friends complete certain actions or milestones for the rewards to be triggered.",
    "We'll keep track of successful referrals for you.",
    "Read the terms and conditions to know all the details about the referral program.",
    "Invite your friends and enjoy the benefits together!",
    "We'll make sure to prevent any misuse of the referral program.",
]

export { transactionHistoryDummy, referralWorkDummy }