// import { joi } from '../index.js'

// const editProfileValidator = joi.object().keys({
//     fullName: joi.string().required().description("firstName"),
//     email: joi.string().email().required().description("email"),
//     city: joi.string().required().description("city"),
//     state: joi.string().required().description("state"),
//     zipCode: joi.number().required().description("zipCode"),
//     mobileNumber: joi.number().min(10).max(10).required().description("mobileNumber"),
//     profile: joi.string().required().description("profile")
// })

// export {
//     editProfileValidator
// }