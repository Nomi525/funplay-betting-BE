import {
    ResponseMessage, StatusCodes, createError, sendResponse, dataCreate, dataUpdated,
    getSingleData, getAllData, Rating
} from "../../index.js";

export const addEditRating = async (req, res) => {
    try {
        const { gameId, rating } = req.body;
        const findRating = await getSingleData({ userId: req.user, gameId }, Rating);
        if (findRating) {
            const updateRating = await dataUpdated({ userId: req.user, gameId }, { rating }, Rating);
            return sendResponse(res, StatusCodes.OK, ResponseMessage.DATA_UPDATED, updateRating);
        } else {
            const createRating = await dataCreate({ userId: req.user, gameId, rating }, Rating);
            return sendResponse(res, StatusCodes.CREATED, ResponseMessage.DATA_CREATED, createRating);
        }
    } catch (error) {
        return createError(res, error);
    }
}

export const gameRatingAverage = async (req, res) => {
    try {
        const gameId = req.body.gameId;
        const ratings = await getAllData({ gameId }, Rating);
        if (ratings.length) {
            const totalScore = ratings.reduce((sum, rating) => sum + rating.rating, 0);
            const averageScore = totalScore / ratings.length;
            return sendResponse(res, StatusCodes.OK, ResponseMessage.GAME_RATING_AVERAGE, averageScore);
        } else {
            return sendResponse(res, StatusCodes.NOT_FOUND, ResponseMessage.DATA_NOT_FOUND, []);
        }
    } catch (error) {
        return createError(res, error);
    }
}